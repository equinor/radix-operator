#!/bin/bash

echo "foo=valueoffoo" >> $GITHUB_ENV